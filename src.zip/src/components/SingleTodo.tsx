import React from 'react'
import { AiFillEdit,AiFillDelete } from 'react-icons/ai'
import { MdDone } from "react-icons/md";
export default function SingleTodo() {
  return (
    <div className='todo'>
        <div className="content">

        </div>
        <div className="actions">
            <AiFillEdit />
            <AiFillDelete />
            <MdDone />
        </div>
    </div>
  )
}
