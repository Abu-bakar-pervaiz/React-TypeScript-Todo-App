export default interface Todo{
    id:number,
    content:string,
    isDone:boolean
}